import React from 'react';
import ReactDOM from 'react-dom/client';
import Pais from './Pais.jsx';
import './Pais.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Pais />
  </React.StrictMode>,
);
