import React, { useState, useEffect } from 'react';

function Paises() {
  const [paises, setPaises] = useState([]);
  const [favoritos, setFavoritos] = useState([]);

  useEffect(() => {
    fetch('./paises.json')
      .then(response => response.json())
      .then(data => setPaises(data));
  }, []);

  const adicionarFavorito = (pais) => {
    if (!favoritos.includes(pais)) {
      setFavoritos([...favoritos, pais]);
    }
  };

  const calcularPopulacaoTotal = () => {
    return paises.reduce((total, pais) => total + pais.population, 0);
  };

  return (
    <div className="tabelas-container">
      <div>
        <table id='paises'>
          <thead>
            <tr>
              <th>Nome</th>
              <th>População</th>
              <th>Bandeira</th>
              <th>Id</th>
              <th>Ação</th>
            </tr>
          </thead>
          <tbody>
            {paises.map((pais) => (
              <tr key={pais.numericCode}>
                <td>{pais.name}</td>
                <td>{pais.population}</td>
                <td><img src={pais.flag} alt={`Bandeira de ${pais.name}`} width="50" /></td>
                <td>{pais.numericCode}</td>
                <td>
                  <button onClick={() => adicionarFavorito(pais)}>Favoritar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="populacao-total">
          População Total: {calcularPopulacaoTotal()}
        </div>
      </div>

      <table id='paises-2'>
        <thead>
          <tr>
            <th>Nome</th>
            <th>População Total</th>
            <th>Bandeira</th>
            <th>Id</th>
          </tr>
        </thead>
        <tbody>
          {favoritos.map((pais) => (
            <tr key={pais.numericCode}>
              <td>{pais.name}</td>
              <td>{pais.population}</td>
              <td><img src={pais.flag} alt={`Bandeira de ${pais.name}`} width="50" /></td>
              <td>{pais.numericCode}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Paises;
